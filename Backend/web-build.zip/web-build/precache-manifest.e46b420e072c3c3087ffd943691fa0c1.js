self.__precacheManifest = [
  {
    "revision": "bc9fd51db77b07ee3ba0",
    "url": "/static/js/app.d66fb230.chunk.js"
  },
  {
    "revision": "66090dc4495d4ce3dfb9",
    "url": "/static/js/runtime~app.2e9f1821.js"
  },
  {
    "revision": "3380471ee67440aca52d",
    "url": "/static/js/2.b566aff8.chunk.js"
  },
  {
    "revision": "ad602f63ddd3755003aec36e4f693181",
    "url": "/static/media/are you feeling it now mr krabs.0937fa4e.png"
  },
  {
    "revision": "44f4bbc042bd0254b774fee8af55cd9d",
    "url": "/index.html"
  },
  {
    "revision": "ec543248d7b23864564429fc03837190",
    "url": "/serve.json"
  },
  {
    "revision": "2002987acac9deb6803ab4ba381226ba",
    "url": "/expo-service-worker.js"
  },
  {
    "revision": "e802d2644326fd9fa701f1d969a8a94a",
    "url": "/register-service-worker.js"
  },
  {
    "revision": "38c76562e525464d43049080e14520cd",
    "url": "/static/js/2.b566aff8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d324ddc823eca6c86688f62576c81e76",
    "url": "/favicon-16.png"
  },
  {
    "revision": "e72daee58e37c99d3553059eda418aa8",
    "url": "/favicon-32.png"
  },
  {
    "revision": "a6e9790fb9b2a50bd52043f66c41b56c",
    "url": "/favicon.ico"
  },
  {
    "revision": "841c1fd4c3661781e00e1b7ea09064f3",
    "url": "/manifest.json"
  }
];